package org.example.doansummer2026.controller;

import lombok.RequiredArgsConstructor;
import org.example.doansummer2026.common.PageResponse;
import org.example.doansummer2026.common.RestResponses;
import org.example.doansummer2026.dto.account.AccountManagementResponse;
import org.example.doansummer2026.dto.account.AccountResponse;
import org.example.doansummer2026.dto.account.AccountUpdateRequest;
import org.example.doansummer2026.enums.Role;
import org.example.doansummer2026.enums.SystemRole;
import org.example.doansummer2026.repository.StaffInfoRepository;
import org.example.doansummer2026.service.AccountService;
import org.example.doansummer2026.service.AuthService;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.example.doansummer2026.aop.Auditable;
import org.example.doansummer2026.enums.AuditAction;

import java.util.UUID;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/accounts")
@RequiredArgsConstructor
@PreAuthorize("hasAnyRole('ADMIN', 'STAFF')")
public class AccountController {

    private final AccountService accountService;
    private final StaffInfoRepository staffRepo;
    private final AuthService authService;

    private void checkManagementPermission(SystemRole targetRole) {
        SystemRole currentRole = authService.getCurrentSystemRole();
        if (targetRole == SystemRole.CLINIC_MANAGER && currentRole == SystemRole.ADMIN) {
            throw new AccessDeniedException("Quản trị viên không có quyền thao tác trên tài khoản Quản lý phòng khám");
        }
        if (currentRole == SystemRole.CLINIC_MANAGER
                && (targetRole == SystemRole.ADMIN || targetRole == SystemRole.CLINIC_MANAGER)) {
            throw new AccessDeniedException("Quản lý phòng khám không có quyền thao tác trên tài khoản quản trị hệ thống hoặc quản lý phòng khám khác");
        }
    }

    private SystemRole getTargetSystemRole(UUID accountId) {
        var account = accountService.findById(accountId);
        return staffRepo.findFirstByProfile_Account_Username(account.getUsername())
                .map(staff -> staff.getSystemRole())
                .orElse(null);
    }

    @GetMapping
    @PreAuthorize("hasAnyAuthority('ROLE_ADMIN','ROLE_CLINIC_MANAGER')")
    public ResponseEntity<PageResponse<AccountResponse>> list(
            @RequestParam(required = false) Role role,
            Pageable pageable) {
        return RestResponses.ok(accountService.list(role, pageable));
    }

    /**
     * API danh sach tai khoan nhan su (staff) - CHỉ ADMIN vaf CLINIC_MANAGER.
     */
    @GetMapping("/staff")
    @PreAuthorize("hasAnyAuthority('ROLE_ADMIN','ROLE_CLINIC_MANAGER')")
    public ResponseEntity<PageResponse<AccountManagementResponse>> listStaff(
            @RequestParam(required = false) String search,
            @RequestParam(required = false) SystemRole systemRole,
            Pageable pageable) {
        return RestResponses.ok(accountService.listStaff(search, systemRole, pageable));
    }

    /**
     * API danh sach tai khoan khach hang (customer) - CHỉ ADMIN vaf CLINIC_MANAGER.
     */
    @GetMapping("/customers")
    @PreAuthorize("hasAnyAuthority('ROLE_ADMIN','ROLE_CLINIC_MANAGER')")
    public ResponseEntity<PageResponse<AccountManagementResponse>> listCustomers(
            @RequestParam(required = false) String search,
            @RequestParam(required = false) String status,
            Pageable pageable) {
        return RestResponses.ok(accountService.listCustomers(search, status, pageable));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('ROLE_ADMIN','ROLE_CLINIC_MANAGER')")
    public ResponseEntity<AccountResponse> get(@PathVariable UUID id) {
        var account = accountService.findById(id);
        SystemRole systemRole = staffRepo.findFirstByProfile_Account_Username(account.getUsername())
                .map(staff -> staff.getSystemRole())
                .orElse(null);
        checkManagementPermission(systemRole);
        return RestResponses.ok(AccountResponse.from(account, systemRole));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('ROLE_ADMIN','ROLE_CLINIC_MANAGER')")
    @Auditable(action = AuditAction.UPDATE, entityName = "Account", idParamName = "id")
    public ResponseEntity<AccountResponse> update(@PathVariable UUID id,
                                                  @RequestBody AccountUpdateRequest req) {
        var account = accountService.findById(id);
        SystemRole systemRole = staffRepo.findFirstByProfile_Account_Username(account.getUsername())
                .map(staff -> staff.getSystemRole())
                .orElse(null);
        checkManagementPermission(systemRole);
        
        account = accountService.update(id, req);
        return RestResponses.ok(AccountResponse.from(account, systemRole));
    }

    @PutMapping("/{id}/password-reset")
    @PreAuthorize("hasAnyAuthority('ROLE_ADMIN','ROLE_CLINIC_MANAGER')")
    @Auditable(action = AuditAction.UPDATE, entityName = "Account", idParamName = "id")
    public ResponseEntity<Void> adminResetPassword(@PathVariable UUID id,
                                                  @RequestBody Map<String, String> payload) {
        var account = accountService.findById(id);
        SystemRole systemRole = staffRepo.findFirstByProfile_Account_Username(account.getUsername())
                .map(staff -> staff.getSystemRole())
                .orElse(null);
        checkManagementPermission(systemRole);

        String newPassword = payload.get("newPassword");
        accountService.adminResetPassword(id, newPassword);
        return RestResponses.noContent();
    }

    /**
     * Khóa/mở tài khoản - CHỉ ADMIN
     * KHÔNG cho phép khóa tài khoản ADMIN hoặc CLINIC_MANAGER.
     */
    @PatchMapping("/{id}/lock")
    @PreAuthorize("hasAnyAuthority('ROLE_ADMIN','ROLE_CLINIC_MANAGER')")
    @Auditable(action = AuditAction.STATUS_CHANGE, entityName = "Account", idParamName = "id")
    public ResponseEntity<AccountResponse> lock(@PathVariable UUID id) {
        checkManagementPermission(getTargetSystemRole(id));
        var account = accountService.lock(id);
        SystemRole systemRole = staffRepo.findFirstByProfile_Account_Username(account.getUsername())
                .map(staff -> staff.getSystemRole())
                .orElse(null);
        return RestResponses.ok(AccountResponse.from(account, systemRole));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('ROLE_ADMIN','ROLE_CLINIC_MANAGER')")
    @Auditable(action = AuditAction.DELETE, entityName = "Account", idParamName = "id")
    public ResponseEntity<Void> delete(@PathVariable UUID id) {
        checkManagementPermission(getTargetSystemRole(id));
        accountService.softDelete(id);
        return RestResponses.noContent();
    }
}
