package org.example.doansummer2026.dto.medicalRecord;

import jakarta.validation.constraints.Size;
import org.example.doansummer2026.dto.icd.ICD10SelectionCreateRequest;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;
import tools.jackson.databind.JsonNode;

public record MedicalRecordUpdateRequest(
        @Size(max = 2000) String chiefComplaint,
        @Size(max = 2000) String clinicalFindings,
        @Size(max = 2000) String diagnosis,
        @Size(max = 2000) String prescriptionNote,
        @Size(max = 2000) String conclusion,
        @Size(max = 2000) String patientInstruction,
        // Vital signs - cap nhat khi luu nham/ket luuan
        String bloodPressure,
        Integer heartRate,
        BigDecimal temperature,
        BigDecimal weight,
        BigDecimal height,
        // Danh sach thuoc trong don thuoc (thay the ca danh sach cu khi cap nhat)
        List<PrescriptionItemCreateRequest> prescriptionItems,
        // Danh sach benh chuan doan ICD-10 (thay the ca danh sach cu khi cap nhat)
        List<ICD10SelectionCreateRequest> icdSelections,
        // Danh sach yeu cau xet nghiem tao cung luc khi ket luuan
        // Neu co -> tao TestRequest, queue ticket chuyen sang WAITING_FOR_TEST
        // Neu khong co -> queue ticket chuyen sang DONE
        List<TestRequestInExaminationRequest> testRequests,
        // Yeu cau tai kham (follow-up)
        FollowUpRequest followUp,
        UUID formTemplateVersionId,
        JsonNode specialtyData,
        Long version
) {}

