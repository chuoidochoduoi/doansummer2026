package org.example.doansummer2026.dto.clinicalForm;

import jakarta.validation.constraints.NotNull;
import java.util.List;
import java.util.UUID;

public record ClinicalFormBindingRequest(@NotNull List<UUID> serviceIds) {}
